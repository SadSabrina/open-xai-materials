# tcav.zip: источники изображений

Текстуры `concepts/striped`, `concepts/zigzagged`, `concepts/dotted` нарисованы скриптом `16_428286_fix1018b_tcav_data.py` (open-xai-materials-private, `stepik_next/toy_examples/`), сид 0; их можно использовать без ограничений (CC0).

Фотографии взяты с Wikimedia Commons и уменьшены до короткой стороны 256 пикселей.

| файл | автор | лицензия | страница |
|---|---|---|---|
| `data/zebra/zebra_000.jpg` | Stano Novak | CC BY 2.5 | https://commons.wikimedia.org/wiki/File:Zebra_02.jpg |
| `data/zebra/zebra_001.jpg` | Taken & submitted by Paul Maritz (PaulmazModified by Pharaoh Hound | CC BY 2.5 | https://commons.wikimedia.org/wiki/File:Zebra_Botswana_edit.jpg |
| `data/zebra/zebra_002.jpg` | George Brits georgebrits_cableandgrain | CC0 | https://commons.wikimedia.org/wiki/File:Zebra_squared_(Unsplash).jpg |
| `data/zebra/zebra_003.jpg` | Denis Lintner | CC BY 3.0 | https://commons.wikimedia.org/wiki/File:Zebra_(189882885).jpeg |
| `data/zebra/zebra_004.jpg` | Steve Evans from Citizen of the World | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(8137989014).jpg |
| `data/zebra/zebra_005.jpg` | safaritravelplus | CC0 | https://commons.wikimedia.org/wiki/File:Zebra_Africa.jpg |
| `data/zebra/zebra_006.jpg` | Rennett Stowe from USA | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Baby_Zebra_(2788749806).jpg |
| `data/zebra/zebra_007.jpg` | Martyn Smith from Leeds, England | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Dining_zebra_(26863484178).jpg |
| `data/zebra/zebra_008.jpg` | Steve Evans from Citizen of the World | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(8167770617).jpg |
| `data/zebra/zebra_009.jpg` | David Minty | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(Botswana_Reserve).jpg |
| `data/zebra/zebra_010.jpg` | Tamar Assaf | Public domain | https://commons.wikimedia.org/wiki/File:Zebra_eating.jpg |
| `data/zebra/zebra_011.jpg` | Andy Witchger | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_zebras_-_tarangire_tanzania_africa.jpg |
| `data/zebra/zebra_012.jpg` | South African Tourism from South Africa | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Suckling_Zebra_Foal,_North_West_Province_(6252731261).jpg |
| `data/zebra/zebra_013.jpg` | Chase Bohannon | CC0 | https://commons.wikimedia.org/wiki/File:A_Zebra_That_Feels_Free.jpg |
| `data/zebra/zebra_014.jpg` | Brian Ralphs from Berkhamsted, Hertfordshire, UK | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Cape_Mountain_Zebra.jpg |
| `data/zebra/zebra_015.jpg` | safaritravelplus | CC0 | https://commons.wikimedia.org/wiki/File:Zebras_In_The_Wild.jpg |
| `data/zebra/zebra_016.jpg` | Yu Miyawaki | CC BY 3.0 | https://commons.wikimedia.org/wiki/File:Zebra_(133192461).jpeg |
| `data/zebra/zebra_017.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(14965195236).jpg |
| `data/zebra/zebra_018.jpg` | Mussi Katz | CC0 | https://commons.wikimedia.org/wiki/File:Zebra_(24694097565).jpg |
| `data/zebra/zebra_019.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(51845236922).jpg |
| `data/zebra/zebra_020.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(51846523819).jpg |
| `data/zebra/zebra_021.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(51846909225).jpg |
| `data/zebra/zebra_022.jpg` | Malcolm Macgregor | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(6141801198).jpg |
| `data/zebra/zebra_023.jpg` | Chris Eason from London | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(7281539418).jpg |
| `data/zebra/zebra_024.jpg` | Miroslav.vajdic | CC BY 4.0 | https://commons.wikimedia.org/wiki/File:Zebra_z1.jpg |
| `data/zebra/zebra_025.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Burchell%27s_zebra_(8565967461).jpg |
| `data/zebra/zebra_026.jpg` | Chris Eason from London | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Evening,_zebra_(394406696).jpg |
| `data/zebra/zebra_027.jpg` | shankar s. from Dubai, united arab emirates | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Masai_Zebra_(7513441966).jpg |
| `data/zebra/zebra_028.jpg` | Derek Keats from Johannesburg, South Africa | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Plains_zebra_(common_zebra_or_Burchell%27s_zebra),_Equus_quagga_at_Pilanesberg_National_Park,_Northwest_Province,_South_Africa_(16906289242).jpg |
| `data/zebra/zebra_029.jpg` | Chris Eason from London | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Young_Zebra_(2320922635).jpg |
| `data/zebra/zebra_030.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra,_Madikwe_(52222009597).jpg |
| `data/zebra/zebra_031.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra,_Madikwe_(52254217388).jpg |
| `data/zebra/zebra_032.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra,_Madikwe_(53514355361).jpg |
| `data/zebra/zebra_033.jpg` | flowcomm | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(51846166931).jpg |
| `data/zebra/zebra_034.jpg` | Martijn.Munneke from Netherlands | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:Zebra_(6558959135).jpg |
| `concepts/random500_0/random0_000.jpg` | Richie Lugo richie_lugo | CC0 | https://commons.wikimedia.org/wiki/File:Worship!_(Unsplash).jpg |
| `concepts/random500_0/random0_001.jpg` | Jeff Vd Assem djeph | CC0 | https://commons.wikimedia.org/wiki/File:Cloud_shadow_on_the_woods_(Unsplash).jpg |
| `concepts/random500_0/random0_002.jpg` | Danielle MacInnes dsmacinnes | CC0 | https://commons.wikimedia.org/wiki/File:Blue_and_White_Party_Straws_in_Mason_Jars_(Unsplash).jpg |
| `concepts/random500_0/random0_003.jpg` | Kelly Sikkema kelsikkema | CC0 | https://commons.wikimedia.org/wiki/File:Recording_Mic_(Unsplash).jpg |
| `concepts/random500_0/random0_004.jpg` | Clem Onojeghuo clemono2 | CC0 | https://commons.wikimedia.org/wiki/File:Gourmet_Cupcakes_(Unsplash).jpg |
| `concepts/random500_0/random0_005.jpg` | Ehimetalor Unuabona becomeincognito | CC0 | https://commons.wikimedia.org/wiki/File:Concerned_Phone_Call_(Unsplash).jpg |
| `concepts/random500_0/random0_006.jpg` | Joshua Harvey josharvey | CC0 | https://commons.wikimedia.org/wiki/File:Snowdon_mountain_hiking_(Unsplash).jpg |
| `concepts/random500_0/random0_007.jpg` | Kayle Kaupanger notaphotographer | CC0 | https://commons.wikimedia.org/wiki/File:Political_Protests_(Unsplash).jpg |
| `concepts/random500_0/random0_008.jpg` | Mitchell Schwartz mitsch | CC0 | https://commons.wikimedia.org/wiki/File:Driftwood_at_the_sand_beach_(Unsplash).jpg |
| `concepts/random500_0/random0_009.jpg` | George Hiles hilesy | CC0 | https://commons.wikimedia.org/wiki/File:Tousled_horse_mane_(Unsplash).jpg |
| `concepts/random500_0/random0_010.jpg` | Harli  Marten harlimarten | CC0 | https://commons.wikimedia.org/wiki/File:Child%27s_glove_on_tree_(Unsplash).jpg |
| `concepts/random500_0/random0_011.jpg` | pepe nero pepe_nero | CC0 | https://commons.wikimedia.org/wiki/File:Zen_Garden_(Unsplash).jpg |
| `concepts/random500_0/random0_012.jpg` | Tommy Tang ttoommy | CC0 | https://commons.wikimedia.org/wiki/File:Point_Dume_State_Beach_(Unsplash).jpg |
| `concepts/random500_0/random0_013.jpg` | Caroline Attwood carolineattwood | CC0 | https://commons.wikimedia.org/wiki/File:Urban_Produce_Shopping_(Unsplash).jpg |
| `concepts/random500_0/random0_014.jpg` | Priscilla Du Preez artographybyp | CC0 | https://commons.wikimedia.org/wiki/File:Trumpeter_in_a_rural_setting_(Unsplash).jpg |
| `concepts/random500_0/random0_015.jpg` | pan xiaozhen zhenhappy | CC0 | https://commons.wikimedia.org/wiki/File:Fall_(Unsplash).jpg |
| `concepts/random500_0/random0_016.jpg` | Viktor Kern viktorkern | CC0 | https://commons.wikimedia.org/wiki/File:Bicycles_For_Rent_(Unsplash).jpg |
| `concepts/random500_0/random0_017.jpg` | Thom thomweerd | CC0 | https://commons.wikimedia.org/wiki/File:Half_closed_laptop_(Unsplash).jpg |
| `concepts/random500_0/random0_018.jpg` | Josh Applegate joshapplegate | CC0 | https://commons.wikimedia.org/wiki/File:Tenebrae_(Unsplash).jpg |
| `concepts/random500_0/random0_019.jpg` | Hanny Naibaho hannynaibaho | CC0 | https://commons.wikimedia.org/wiki/File:Lost_in_Wilderness_(Unsplash_pMBoh00wf6s).jpg |
| `concepts/random500_0/random0_020.jpg` | Adam Reber thatcoolguy | CC0 | https://commons.wikimedia.org/wiki/File:Water_drops_on_autumn_leaf_(Unsplash).jpg |
| `concepts/random500_0/random0_021.jpg` | Atte Grönlund gratte | CC0 | https://commons.wikimedia.org/wiki/File:Small_lake_pier_(Unsplash).jpg |
| `concepts/random500_0/random0_022.jpg` | Izzy Gerosa izzygerosa | CC0 | https://commons.wikimedia.org/wiki/File:Waterfall_View_(Unsplash).jpg |
| `concepts/random500_0/random0_023.jpg` | Luca Bravo lucabravo | CC0 | https://commons.wikimedia.org/wiki/File:Rocky_seaside_(Unsplash).jpg |
| `concepts/random500_0/random0_024.jpg` | Ruel Calitis ruelcalitis | CC0 | https://commons.wikimedia.org/wiki/File:Indescribable_(Unsplash).jpg |
| `concepts/random500_0/random0_025.jpg` | Jeremy Bishop tidesinourveins | CC0 | https://commons.wikimedia.org/wiki/File:Unsplash_LA_(Unsplash_DVgSOznWH_M).jpg |
| `concepts/random500_0/random0_026.jpg` | sergey Svechnikov blackout095 | CC0 | https://commons.wikimedia.org/wiki/File:Skater_Boy_(Unsplash).jpg |
| `concepts/random500_0/random0_027.jpg` | Shane Rounce shanerounce | CC0 | https://commons.wikimedia.org/wiki/File:Stickerrific_(Unsplash).jpg |
| `concepts/random500_0/random0_028.jpg` | Joey Pilgrim joeypilgrim | CC0 | https://commons.wikimedia.org/wiki/File:Midnight_Photographer_(Unsplash).jpg |
| `concepts/random500_0/random0_029.jpg` | Chanan Greenblatt chanan | CC0 | https://commons.wikimedia.org/wiki/File:View_of_a_baseball_game_(Unsplash).jpg |
| `concepts/random500_0/random0_030.jpg` | Ben Neale ben_neale | CC0 | https://commons.wikimedia.org/wiki/File:SPAGHETTI_(Unsplash).jpg |
| `concepts/random500_0/random0_031.jpg` | Jasper Boer jasperboer | CC0 | https://commons.wikimedia.org/wiki/File:Green_Mountain_Landscape_(Unsplash).jpg |
| `concepts/random500_0/random0_032.jpg` | chuttersnap chuttersnap | CC0 | https://commons.wikimedia.org/wiki/File:Two_by_two_(Unsplash).jpg |
| `concepts/random500_0/random0_033.jpg` | Kahar Saidyhalam kahar | CC0 | https://commons.wikimedia.org/wiki/File:Man_with_wrinkles_and_cap_(Unsplash).jpg |
| `concepts/random500_0/random0_034.jpg` | Linh Pham linharex | CC0 | https://commons.wikimedia.org/wiki/File:Letters_(Unsplash).jpg |
| `concepts/random500_0/random0_035.jpg` | Michael Heuser gum_meee | CC0 | https://commons.wikimedia.org/wiki/File:Pier_building_(Unsplash).jpg |
| `concepts/random500_0/random0_036.jpg` | Karl Fredrickson kfred | CC0 | https://commons.wikimedia.org/wiki/File:Sunrise_in_Palm_Beach_(Unsplash).jpg |
| `concepts/random500_0/random0_037.jpg` | Jon Phillips jonphillips | CC0 | https://commons.wikimedia.org/wiki/File:Jon-phillips-unsplash_(Unsplash).jpg |
| `concepts/random500_1/random1_000.jpg` | Paul-Louis Pröve pietz | CC0 | https://commons.wikimedia.org/wiki/File:Viaduct_in_the_autumn_(Unsplash).jpg |
| `concepts/random500_1/random1_001.jpg` | Jeremy Bishop tidesinourveins | CC0 | https://commons.wikimedia.org/wiki/File:Unsplash_LA_(Unsplash).jpg |
| `concepts/random500_1/random1_002.jpg` | David Marcu davidmarcu | CC0 | https://commons.wikimedia.org/wiki/File:Alone_in_the_unspoilt_wilderness_(Unsplash).jpg |
| `concepts/random500_1/random1_003.jpg` | Filip Zrnzević filipz | CC0 | https://commons.wikimedia.org/wiki/File:Gray_treelines_(Unsplash).jpg |
| `concepts/random500_1/random1_004.jpg` | Karl Fredrickson kfred | CC0 | https://commons.wikimedia.org/wiki/File:Sunrise_in_Palm_Beach_(Unsplash).jpg |
| `concepts/random500_1/random1_005.jpg` | Taylor Nicole taynicole0630 | CC0 | https://commons.wikimedia.org/wiki/File:View_down_a_ravine_(Unsplash).jpg |
| `concepts/random500_1/random1_006.jpg` | Scott Walsh outsighted | CC0 | https://commons.wikimedia.org/wiki/File:Going_Places_(Unsplash).jpg |
| `concepts/random500_1/random1_007.jpg` | Cameron Kirby ckirby | CC0 | https://commons.wikimedia.org/wiki/File:Palm_trees_(Unsplash).jpg |
| `concepts/random500_1/random1_008.jpg` | Ronald Yang ronzyang | CC0 | https://commons.wikimedia.org/wiki/File:Spaceship_Earth_(Unsplash).jpg |
| `concepts/random500_1/random1_009.jpg` | Tony Webster tonywebster | CC0 | https://commons.wikimedia.org/wiki/File:High_Trestle_Trail_Bridge,_Madrid,_Iowa,_United_States_(Unsplash_F9o7u-CnDJk).jpg |
| `concepts/random500_1/random1_010.jpg` | Frantzou Fleurine frantzou | CC0 | https://commons.wikimedia.org/wiki/File:Rock_By_Sea_(Unsplash).jpg |
| `concepts/random500_1/random1_011.jpg` | William Stitt willpower | CC0 | https://commons.wikimedia.org/wiki/File:Nothing_But_Net_(Unsplash).jpg |
| `concepts/random500_1/random1_012.jpg` | Taduuda taduuda | CC0 | https://commons.wikimedia.org/wiki/File:Check_in_the_book_(Unsplash).jpg |
| `concepts/random500_1/random1_013.jpg` | Carina Höglinger carhoeg | CC0 | https://commons.wikimedia.org/wiki/File:Fog-shrouded_mountain_(Unsplash).jpg |
| `concepts/random500_1/random1_014.jpg` | AJ Garcia ajgarciaco | CC0 | https://commons.wikimedia.org/wiki/File:Parasailing_in_the_Bahamas_(Unsplash).jpg |
| `concepts/random500_1/random1_015.jpg` | ANDRIK ↟ LANGFIELD ↟ PETRIDES jeffoa98 | CC0 | https://commons.wikimedia.org/wiki/File:Sparkling_heart_(Unsplash).jpg |
| `concepts/random500_1/random1_016.jpg` | Graziano De Maio grazianodemaio | CC0 | https://commons.wikimedia.org/wiki/File:Cycling_across_the_mountainside_(Unsplash).jpg |
| `concepts/random500_1/random1_017.jpg` | Fabian Fauth fabster74 | CC0 | https://commons.wikimedia.org/wiki/File:Down_the_stairs_(Unsplash).jpg |
| `concepts/random500_1/random1_018.jpg` | Ferran Fusalba frrn | CC0 | https://commons.wikimedia.org/wiki/File:Woods_and_mountains_(Unsplash).jpg |
| `concepts/random500_1/random1_019.jpg` | Matthew  Sleeper mjsleeper | CC0 | https://commons.wikimedia.org/wiki/File:Neon.2_(Unsplash).jpg |
| `concepts/random500_1/random1_020.jpg` | Ricardo Gomez Angel ripato | CC0 | https://commons.wikimedia.org/wiki/File:Stunning_view_(Unsplash).jpg |
| `concepts/random500_1/random1_021.jpg` | Jakob Owens jakobowens1 | CC0 | https://commons.wikimedia.org/wiki/File:Instamatic_(Unsplash).jpg |
| `concepts/random500_1/random1_022.jpg` | Gemma Evans stayandroam | CC0 | https://commons.wikimedia.org/wiki/File:Delicate_camellia_flowers_(Unsplash).jpg |
| `concepts/random500_1/random1_023.jpg` | Chungkuk Bae zzbe | CC0 | https://commons.wikimedia.org/wiki/File:Cherry_blossoms_(Unsplash).jpg |
| `concepts/random500_1/random1_024.jpg` | Hamish Clark hamishclark_ | CC0 | https://commons.wikimedia.org/wiki/File:Streetlights_and_traffic_light_trails_(Unsplash).jpg |
| `concepts/random500_1/random1_025.jpg` | Clem Onojeghuo clemono2 | CC0 | https://commons.wikimedia.org/wiki/File:Kitchen_table_(Unsplash).jpg |
| `concepts/random500_1/random1_026.jpg` | Samantha Sophia samanthasophia | CC0 | https://commons.wikimedia.org/wiki/File:Strong_Women_(Unsplash).jpg |
| `concepts/random500_1/random1_027.jpg` | Kukuh Himawan Samudro kukuhhimawans | CC0 | https://commons.wikimedia.org/wiki/File:Volcano_at_dusk_(Unsplash).jpg |
| `concepts/random500_1/random1_028.jpg` | Hanny Naibaho hannynaibaho | CC0 | https://commons.wikimedia.org/wiki/File:Rolleiflex_SL35_camera_in_Medan,_Indonesia_(Unsplash).jpg |
| `concepts/random500_1/random1_029.jpg` | Lucca Lazzarini luccalazza | CC0 | https://commons.wikimedia.org/wiki/File:The_Good_Side_(Unsplash).jpg |
| `concepts/random500_1/random1_030.jpg` | Herson Rodriguez hero | CC0 | https://commons.wikimedia.org/wiki/File:Pancakes_with_Berries_(Unsplash).jpg |
| `concepts/random500_1/random1_031.jpg` | quentin lagache quentinlagache | CC0 | https://commons.wikimedia.org/wiki/File:Summertime_Tea_(Unsplash).jpg |
| `concepts/random500_1/random1_032.jpg` | aaronburden Aaron Burden from Baltimore, Maryland, USA. | CC0 | https://commons.wikimedia.org/wiki/File:Frozen_soap_bubble_behind_fir_twigs_(Unsplash_BojuZpqw4zM).jpg |
| `concepts/random500_1/random1_033.jpg` | Felipe Portella f_portella | CC0 | https://commons.wikimedia.org/wiki/File:Duo_Andes_(Unsplash).jpg |
| `concepts/random500_1/random1_034.jpg` | Clem Onojeghuo clemono2 | CC0 | https://commons.wikimedia.org/wiki/File:Unsplash_lapel_pin_(Unsplash).jpg |
| `concepts/random500_1/random1_035.jpg` | Nirzar Pangarkar nirzar | CC0 | https://commons.wikimedia.org/wiki/File:Sunday_Kitty_(Unsplash).jpg |
| `concepts/random500_1/random1_036.jpg` | Steve Shreve steveshreve | CC0 | https://commons.wikimedia.org/wiki/File:Lights_(Unsplash).jpg |
| `concepts/random500_1/random1_037.jpg` | Tomo Nogi tomonogi | CC0 | https://commons.wikimedia.org/wiki/File:Windy_(Unsplash).jpg |
| `concepts/random500_1/random1_038.jpg` | Alex Holyoake stairhopper | CC0 | https://commons.wikimedia.org/wiki/File:Photographing_coats_(Unsplash).jpg |
| `concepts/random500_1/random1_039.jpg` | Eric Welch eric_welch | CC0 | https://commons.wikimedia.org/wiki/File:Melting_Time_(Unsplash).jpg |
| `concepts/random500_1/random1_040.jpg` | Henrique Félix henriquefelix | CC0 | https://commons.wikimedia.org/wiki/File:People_at_pedestrian_crossing_(Unsplash).jpg |
